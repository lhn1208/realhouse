'use strict';
$(document).ready(function(){
	//공통탭
	// $body.find('.iti_tab li').on('click','>a, >label', function(){
	// 	var _this = $(this);
	// 	var i =  _this.parent().index();
	// 	 _this.closest('.iti_tab').siblings('.iti_tab_wrap').children('.tab_content').eq(i).show().siblings().hide();
	// 	 _this.parent('li').addClass('current').siblings().removeClass('current');
	// 	return false;
	// }).parent('li').siblings().eq(0).trigger('click');

});